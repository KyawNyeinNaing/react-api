import React from 'react'
import AppLayout from './layout'

const App = () => {
  return (
    <AppLayout />
  )
}

export default App
