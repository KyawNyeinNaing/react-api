import React from 'react'
import styled from 'styled-components'
import { Link } from 'react-router-dom'

const Nav = styled.nav`
  ul {
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    li {
      margin-right: 15px;
      a {
        text-decoration: none;
      }
    }
  }
`

const Header = () => {
  return (
    <Nav>
      <ul>
        <li>
          <Link to="/home/posts">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
      </ul>
    </Nav>
  )
}

export default Header
