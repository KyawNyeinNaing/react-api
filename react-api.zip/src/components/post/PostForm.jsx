import React from 'react'

const PostForm = () => {
  return (
    <div>
      <form action="">
        <div>
          <input type="text" name="userId" />
        </div>
        <div>
          <input type="text" name="title" />
        </div>
        <div>
          <input type="text" name="body" />
        </div>
      </form>
    </div>
  )
}

export default PostForm
