export { default as PostList } from './PostsList'

export { default as PostDetail } from './PostsDetail'