import React from 'react'

const Contact = () => {
  return (
    <div>
      This is contact
    </div>
  )
}

export default Contact
